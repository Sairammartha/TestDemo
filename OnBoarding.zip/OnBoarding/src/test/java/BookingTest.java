import framework.HtmlReporter;
import module.GeneralMethods;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;
import pageobjects.*;

import java.util.HashMap;

public class BookingTest extends GeneralMethods {

    @Test(dataProvider = "input")
    public void createBooking(@Optional HashMap<String, String> input) {
        int noBookingItem = 1;
        if (input.containsKey("NoOfBookingItems"))
            noBookingItem = Integer.parseInt(input.get("NoOfBookingItems"));
        for (int i = 0; i < noBookingItem; i++) {
            try {
                noBookingItems = i;
                HtmlReporter.testParent = HtmlReporter.extent.createTest("Create " + input.get("Booking Type") + " Booking for City : ' " + input.get("City"));
                launch();
                if (!driver.getTitle().contains("SIMPLENIGHT"))
                    searchAvailability(input);
                getDetails(input);
                guestDetails(input);
                makePayment(input);
                cancelBooking(input);

            } catch (Exception exception) {
                System.out.println("Booking creation failed");
            } finally {
                skip=false;
                driver.close();
                driver.quit();
                driver = null;

            }
        }
    }

    @Test(dataProvider = "input")
    public void createTranportBooking(@Optional HashMap<String, String> input) {
        HtmlReporter.testParent = HtmlReporter.extent.createTest("Create " + input.get("Booking Type") + " Booking for City : ' " + input.get("City"));
        launch();
        searchAvailability(input);
        getTransportationDetails(input);
        guestDetails(input);
        makePayment(input);
        cancelBooking(input);

    }

    @Test(dataProvider = "input")
    public void createDiningBooking(@Optional HashMap<String, String> input) {
        HtmlReporter.testParent = HtmlReporter.extent.createTest("Create " + input.get("Booking Type") + " Booking for City : ' " + input.get("City"));
        launch();
        searchAvailability(input);
        getDiningDetails(input);
        guestDetails(input);
        orderSummary(input);
        cancelBooking(input);

    }


}

