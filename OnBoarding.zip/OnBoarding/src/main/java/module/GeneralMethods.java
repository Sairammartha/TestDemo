package module;

import framework.Base;
import framework.HtmlReporter;
import org.openqa.selenium.WebDriver;
import org.testng.SkipException;
import org.testng.annotations.Optional;
import org.testng.annotations.Test;
import pageobjects.*;

import java.util.HashMap;

public class GeneralMethods extends Base {
    static String orderNum = "", url = "";


    public boolean skipExecution(String methodName) {
        if (skip) {
            HtmlReporter.reportSkip(methodName + " Test case skipped");
            throw new SkipException("Skipping execution");

        }
        return skip;
    }

    public void launch() {
        driver = initializeDriver();
        url = readProperty(System.getProperty("user.dir") + "/resources/config.properties").getProperty("URL");
        driver.get(url);
        HtmlReporter.reportPass(" Application launched successfully");
//
    }

    public void searchAvailability(HashMap<String, String> input) {
        if (skipExecution("searchAvailability"))
            return;
        HomePage hm = new HomePage(driver);
        setValue(hm.getSearch(), input.get("City"));
        waitForBrowserStability(30);
        wait(1000);
        isElementPresent(hm.getSelectCity(input.get("City")));
        waitUntilElementPresent(hm.getSelectCity(input.get("City")));
        clickElement(hm.getSelectCity(input.get("City")));
        clickElement(hm.getFrom());
        hm.setDate(input.get("FromDate"));
        clickElement(hm.getUntill());
        hm.setDate(input.get("Untilldate"));
        clickElement(hm.getSubmitButton());
        waitForBrowserStability(30);
        if (isElementPresent(hm.getErrorMessage()))
            HtmlReporter.reportFail(input.get("City") + " Search results not displayed " + hm.getErrorMessage().getText());
        else
            HtmlReporter.reportPass(input.get("City") + " Search results is displayed ");

    }


    public void getDetails(HashMap<String, String> input) {
        if (skipExecution("getDetails"))
            return;
        MenuPage menuPage = new MenuPage(driver);
        if (driver.getTitle().contains("SIMPLENIGHT")) {
            waitForBrowserStability(30);
            wait(1000);
            waitUntilElementPresent(menuPage.getEditButton());
            if (isElementPresent(menuPage.getEditButton()))
                clickElement(menuPage.getEditButton());
            HomePage hm = new HomePage(driver);
            setValue(hm.getSearch(), input.get("City"));
            waitForBrowserStability(30);
            wait(2000);
            if(driver.getCurrentUrl().contains("demo"))
                wait(30000);
            isElementPresent(hm.getSelectCity(input.get("City")));
            waitUntilElementPresent(hm.getSelectCity(input.get("City")));
            clickElement(hm.getSelectCity(input.get("City")));
            clickElement(hm.getFrom());
            hm.setDate(input.get("FromDate"));
            clickElement(hm.getUntill());
            hm.setDate(input.get("Untilldate"));
            clickElement(menuPage.getSearchButton());
            waitElementISNotPresent(menuPage.getLoader(), 40);
        } else {
            clickElement(menuPage.getDashboardFilter(input.get("Booking Type")));
            waitElementISNotPresent(menuPage.getLoader(), 30);
            if (input.containsKey("Provider")) {
                clickElement(menuPage.getEditButton());
                clickElement(menuPage.getArrowButton());
                clickElement(menuPage.getSelectProvider(input.get("Provider")));
                clickElement(menuPage.getSearchButton());
                waitElementISNotPresent(menuPage.getLoader(), 30);
            }
        }
        waitElementISNotPresent(menuPage.getLoader(), 30);
        if (isElementPresent(menuPage.getNoRecordsFound())) {
            HtmlReporter.reportFail(" No availability for " + input.get("Booking Type"));
            skip = true;
            return;
        }
        if (input.get("Booking Type").equals("Hotels"))
            clickElement(menuPage.getHotelSortBy());
        else
            clickElement(menuPage.getTravelSortBy());
        clickElement(menuPage.getLowToHigh());
        waitElementISNotPresent(menuPage.getLoader(), 30);
        wait(2000);
        if (input.containsKey("NoOfBookingItems")) {
            clickElement(menuPage.getBookingItems().get(noBookingItems));
        } else {
            waitUntilElementPresent(menuPage.getSelectItem(input.get("Booking Name")));
            if (isElementPresent(menuPage.getSelectItem(input.get("Booking Name"))))
                clickElement(menuPage.getSelectItem(input.get("Booking Name")));
            else {
                HtmlReporter.reportFail(input.get("Booking Name") + " is not available on " + input.get("Booking Type"));
                skip = true;
                return;
            }
        }
        if (isElementPresent(menuPage.getErrorMessage())) {
            HtmlReporter.reportFail("No availability  " + menuPage.getErrorMessage().getAttribute("innerText"));
            skip = true;
            return;
        }
        waitElementISNotPresent(menuPage.getLoader(), 30);
        if (isElementPresent(menuPage.getNoDataMessage())) {
            HtmlReporter.reportFail(" No Inventory " + input.get("Booking Name") + menuPage.getNoDataMessage().getText());
            skip = true;
            return;
        }
        if (!isElementPresent(menuPage.getAddButton())) {
            HtmlReporter.reportFail(" No Inventory " + input.get("Booking Name"));
            skip = true;
            return;
        }
        HtmlReporter.reportPassFail(isElementPresent(menuPage.getVerifyDetails()), "Inventory details displayed", "Inventory details not displayed");
        clickElement(menuPage.getDetailsLink());
        HtmlReporter.reportPassFail(isElementPresent(menuPage.getVerifyDetails()), "Details are displayed", "Details not displayed");
        clickElement(menuPage.getMapLink());
        waitUntilElementPresent(menuPage.getMapPage());
        HtmlReporter.reportPassFail(isElementPresent(menuPage.getMapPage()), "Maps are displayed", "Maps not displayed");
        clickElement(menuPage.getTabs());

//        if (isElementPresent(menuPage.getVerifyDetails()))
//            HtmlReporter.reportPass("Map are displayed");
//        clickElement(menuPage.getMapLink());
//        if (isElementPresent(menuPage.getMapPage()))
//            HtmlReporter.reportPass("Map are displayed");

        clickElement(menuPage.getAddButton());
        clickElement(menuPage.getOrderNow());

    }

    public void guestDetails(HashMap<String, String> input) {
        if (skipExecution("guestDetails"))
            return;
        GuestInfoPage guestInfo = new GuestInfoPage(driver);
        setValue(guestInfo.getEmailAddress(), input.get("Emaild"));
//        clickElement(guestInfo.getSalutation());
//        clickElement(guestInfo.getSelectSalutation());
        setValue(guestInfo.getFirstName(), input.get("Firstname"));
        setValue(guestInfo.getLastName(), input.get("Lastname"));
        setValue(guestInfo.getAddress(), input.get("Address"));
        setValue(guestInfo.getPostal(), input.get("Postal"));
        setValue(guestInfo.getCountry(), input.get("Country").toUpperCase());
        clickElement(guestInfo.getSelectCountry(input.get("Country").toUpperCase()));
        setValue(guestInfo.getPhoneNumber(), input.get("Phone"));
        HtmlReporter.reportPass("Entered the Guest details");
        if (driver.getCurrentUrl().contains("demo") && input.get("Booking Type").equalsIgnoreCase("Dining")) {
            skip = true;
            return;
        }
        clickElement(guestInfo.getEnterPayment());
        if (isElementPresent(guestInfo.getEnterPayment()))
            clickElement(guestInfo.getEnterPayment());
        if (isElementPresent(guestInfo.getTermsAndConditions()))
            clickElement(guestInfo.getTermsAndConditions());
    }

    public void makePayment(HashMap<String, String> input) {
        if (skipExecution("makePayment"))
            return;
        PaymentPage paymentPage = new PaymentPage(driver);
        waitElementISNotPresent(paymentPage.getLoader(), 30);
        setValue(paymentPage.getCardName(), input.get("CardName"));
//        waitForBrowserStability("50");
//        wait(2000);
        switchToFrame("sq-payment-form-sq-card-number");
//        driver.switchTo().frame("sq-payment-form-sq-card-number");
        setValue(paymentPage.getCardNumber(), input.get("CardNumber"));
        switchToFrame("sq-payment-form-sq-expiration-date");
        setValue(paymentPage.getCardExp(), input.get("CardExpire"));
        switchToFrame("sq-payment-form-sq-cvv");

        setValue(paymentPage.getCvv(), input.get("CardCVV"));
        driver.switchTo().defaultContent();
//        waitElementISNotPresent(paymentPage.getLoader(), 40);
        clickElement(paymentPage.getTerms());
//        if (driver.getCurrentUrl().contains("demo")) {
//            skip = true;
//        } else {
        clickElement(paymentPage.getCheckout());
        orderSummary(input);

//        }
    }

    public void orderSummary(HashMap<String, String> input) {
        if (skipExecution("orderSummary"))
            return;

        PaymentPage paymentPage = new PaymentPage(driver);
        wait(500);
        waitForBrowserStability(30);
        waitElementISNotPresent(paymentPage.getLoader(), 60);
        wait(1000);
        waitUntilElementPresent(paymentPage.getOrderNumber());
        if (isElementPresent(paymentPage.getOrderNumber())) {
            orderNum = paymentPage.getOrderNumber().getText().split("ORDER NUMBER\n")[0];
            HtmlReporter.reportPass("Booking created successfully : " + orderNum);
        } else if (isElementPresent(paymentPage.getErrorMessage())) {
            skip = true;
            HtmlReporter.reportFail("Booking creation failed " + paymentPage.getErrorMessage().getAttribute("innerText"));

        } else if (!isElementPresent(paymentPage.getOrderNumber())) {
            skip = true;
            HtmlReporter.reportFail("Booking creation failed ");

        }
    }

    public void cancelBooking(@Optional HashMap<String, String> input) {
        if (skipExecution("cancelBooking"))
            return;
        driver.get(url + "orderlookup");
        waitForBrowserStability(30);
        CancelPage cancelPage = new CancelPage(driver);

        setValue(cancelPage.getEnterOrderNumber(), orderNum);
        setValue(cancelPage.getLastName(), input.get("Lastname"));
        clickElement(cancelPage.getOrderSearch());
        PaymentPage paymentPage = new PaymentPage(driver);
        wait(1000);
        waitElementISNotPresent(paymentPage.getLoader(), 50);
        waitUntilElementPresent(paymentPage.getOrderNumber());
        if (isElementPresent(paymentPage.getOrderNumber()) && paymentPage.getOrderNumber().getText().split("\n")[1].equals(orderNum))
            HtmlReporter.reportPass("Order Number is verified : " + orderNum);
        else if (isElementPresent(cancelPage.getErrorMessage())) {
//            wait(1000);
            HtmlReporter.reportFail("Error message is displayed " + cancelPage.getErrorMessage().getText());

        }
    }

    public void getTransportationDetails(HashMap<String, String> input) {
        MenuPage menuPage = new MenuPage(driver);
        clickElement(menuPage.getDashboardFilter(input.get("Booking Type")));
        waitElementISNotPresent(menuPage.getLoader(), 20);
        TransportationPage transPage = new TransportationPage(driver);
        setValue(transPage.getPickUp(), input.get("PickUp"));
        clickElement(transPage.getSelectCity(input.get("PickUp")));
        setValue(transPage.getDropOff(), input.get("DropOff"));
        clickElement(transPage.getSelectCity(input.get("DropOff")));
        clickElement(transPage.getSelectDate());
        new HomePage(driver).setDate("16-06-2021");
        clickElement(transPage.getAddPessengers());
        clickElement(transPage.getAddBags());
        clickElement(transPage.getSubmit());
//        waitElementISNotPresent(transPage.getLoader());
//        waitElementISNotPresent(transPage.getLoader(),10);
        wait(1000);
        if (isElementPresent(transPage.getErrorMessage())) {
            HtmlReporter.reportFail("No availability  " + transPage.getErrorMessage().getAttribute("innerText"));
            skip = true;
            return;
        }
        if (!isElementPresent(transPage.getViewButton())) {
            HtmlReporter.reportFail("No Data available ");
            skip = true;
            return;
        }
        clickElement(transPage.getViewButton());
        if (isElementPresent(transPage.getDetails()))
            HtmlReporter.reportPass("Details are displayed");
        clickElement(transPage.getMapLink());
        if (isElementPresent(transPage.getMapPage()))
            HtmlReporter.reportPass("Map are displayed");

        clickElement(transPage.getOrderNowButton());

    }

    public void getDiningDetails(HashMap<String, String> input) {
        MenuPage menuPage = new MenuPage(driver);
        clickElement(menuPage.getDashboardFilter(input.get("Booking Type")));
        waitElementISNotPresent(menuPage.getLoader(), 30);
        DiningInfoPage diningInfoPage = new DiningInfoPage(driver);
        clickElement(diningInfoPage.getSortByFilter());
        clickElement(diningInfoPage.getAscendingOrder());
        wait(1000);
//        clickElement(menuPage.getSelectItem(input.get("Booking Name")));
        if (isElementPresent(menuPage.getSelectItem(input.get("Booking Name"))))
            clickElement(menuPage.getSelectItem(input.get("Booking Name")));
        else {
            HtmlReporter.reportFail(input.get("Booking Name") + " is not available on " + input.get("Booking Type"));
            skip = true;
            return;
        }
        waitElementISNotPresent(menuPage.getLoader(), 20);
        if (isElementPresent(diningInfoPage.getDiningDetails()))
            HtmlReporter.reportPass("Details are displayed");
        else
            HtmlReporter.reportFail("Details are not displayed");
        clickElement(diningInfoPage.getMapLink());
        if (isElementPresent(diningInfoPage.getMapPage()))
            HtmlReporter.reportPass("Maps is displayed");
        else
            HtmlReporter.reportFail("Maps is not displayed");
        clickElement(diningInfoPage.getReview());
        if (isElementPresent(diningInfoPage.getReviewDetails()))
            HtmlReporter.reportPass("Review details are displayed");
        else
            HtmlReporter.reportFail("Review details are not displayed");

        clickElement(menuPage.getAddButton());
        clickElement(diningInfoPage.getSelectTime(input.get("DiningTime")));
//        clickElement(diningInfoPage.getSelectTime());
        clickElement(menuPage.getOrderNow());
        if (isElementPresent(menuPage.getErrorMessage())) {
            HtmlReporter.reportFail("No availability  " + menuPage.getErrorMessage().getAttribute("innerText"));
            skip = true;
            return;
        }
    }
}
