package framework;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.*;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import static framework.HtmlReporter.reportFail;
import static framework.HtmlReporter.reportPath;

public class Base {
    public static WebDriver driver;
    public static String appPath = System.getProperty("user.dir");
    public static Properties prop;
    public static boolean skip = false;
    public static ArrayList<String> methods = new ArrayList<>();
    public static int noBookingItems = 0;

    @DataProvider(name = "input", parallel = false)
    public Object[][] dataProvider(ITestContext context) {

        List<LinkedHashMap<String, String>> inputs = CSV_IO.readCSVFile(System.getProperty("user.dir") + "/resources/Testdata.csv");
        List<LinkedHashMap<String, String>> input = new LinkedList<>();
//context.getCurrentXmlTest().getParameter("TestDataFile") + ".xlsx"
        String bookingType = context.getCurrentXmlTest().getParameter("BookingType");
        for (int i = 0; i < inputs.size(); i++) {
            if (inputs.get(i).get("Booking Type").contains(bookingType))
                input.add(inputs.get(i));
        }
        Object dataArray[][] = new Object[input.size()][1];
        for (int i = 0; i < input.size(); i++) {
            if (input.get(i).get("Booking Type").contains(bookingType))
                dataArray[i][0] = input.get(i);
        }
        return dataArray;
    }

    @BeforeSuite
    public void beforeSuite() {
        reportPath = System.getProperty("user.dir") + "/Reports/" + "ExecutionReport_"
                + new SimpleDateFormat("yyyy_MM_dd_HH_mm_ss").format(new Date());
        new File(reportPath).mkdir();
        HtmlReporter.screenshotFolder = reportPath + "/ScreenShots";
        new File(HtmlReporter.screenshotFolder).mkdir();
        HtmlReporter.htmlReporter = new ExtentHtmlReporter(reportPath + "/" + "ExecutionReport.html");
        HtmlReporter.extent = new ExtentReports();
        HtmlReporter.extent.attachReporter(HtmlReporter.htmlReporter);
//		extent.setSystemInfo("Host Name", "SoftwareTestingMaterial");
//		extent.setSystemInfo("Environment", "Automation Testing");
//		extent.setSystemInfo("User Name", "");

        HtmlReporter.htmlReporter.config().setDocumentTitle("Execution Report");
        HtmlReporter.htmlReporter.config().setReportName("Execution Report");
        HtmlReporter.htmlReporter.config().setTheme(Theme.STANDARD);
//        driver = initializeDriver();
    }

    @BeforeTest
    public void initialize(ITestContext testContext) throws IOException {
        skip = false;
//        HtmlReporter.testParent = HtmlReporter.extent.createTest(testContext.getName());
        //driver = initializeDriver();
        //reportInfo("Before Test","",""+ testContext.getName());
        //log.info("Before Test");
    }

    @BeforeMethod
    public void getMethodName(Method method) throws IOException {
//        HtmlReporter.testParent = HtmlReporter.extent.createTest(method.getName());
        //driver = initializeDriver();
        //reportInfo("Before Test","",""+ testContext.getName());
        //log.info("Before Test");
        skip = false;
        System.out.println("Methods");
        methods.add(method.getName());
        if (method.getName().contains("login"))
            skip = false;

    }

    @AfterMethod
    public void afterMethod() throws IOException {
        HtmlReporter.extent.flush();
        noBookingItems=0;
        if(driver!=null) {
            driver.close();
            driver.quit();
        }

    }

    // @Test(dataProvider = "getLoginData", dataProviderClass =
    // DataProviderClass.class)

    @AfterTest
    public void teardown() throws IOException {

    }

    @AfterSuite
    public void afterSuit() {
        HtmlReporter.extent.flush();
//        driver.close();
//        driver = null;

    }

    public WebDriver initializeDriver() {
        prop = new Properties();
        try {

//                System.setProperty("webdriver.chrome.driver",
//                        appPath + "\\src\\main\\java\\com\\thoughtniques\\icue\\resources\\webdrivers\\chromedriver.exe");
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            // driver.manage().deleteAllCookies();
            driver.manage().timeouts().implicitlyWait(500, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return driver;
    }

    public void getScreenshot(String result) throws IOException {
        String screenShotsPath = appPath + "/testresults/screenshots/";
        File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(src, new File(screenShotsPath + result + ".png"));

    }


    public boolean waitUntilElementPresent(final WebElement webElement) {
        waitForBrowserStability(30);
        try {
            WebDriverWait wait = new WebDriverWait(driver, 30);
            WebElement element = wait.until(ExpectedConditions.visibilityOf(webElement));
            if (element != null) {
                return true;
            } else return false;
        } catch (Exception e) {
            return false;
        }

    }

    public void waitElementISNotPresent1(final WebElement webElement, long timeInSec) {
//        try {
//            WebDriverinWait wait = new WebDriverWait(driver, timeInSec);
//            Boolean element = wait.until(ExpectedConditions.invisibilityOf(webElement));
//            return element;
//        } catch (Exception e) {
//            System.out.println("Element is In-Visible:" + webElement);
//            return true;
//        }

        boolean temp = true;
        int i = 0;
        while (temp) {
            try {
                if (!webElement.isDisplayed() || i == 400)
                    break;
                wait(100);
                i++;

            } catch (Exception e) {
                break;
            }
        }
//        WebDriverWait wait = new WebDriverWait(driver, 30);
//        return wait.until(!webElement.isDisplayed());
//        return true;
    }

    public void waitElementISNotPresent(WebElement element, int seconds) {
        waitForBrowserStability(30);
        try {
            WebDriverWait wait = new WebDriverWait(driver, seconds);
            wait.until(driver1 -> !isElementPresent(element));
        } catch (Exception e) {
            System.out.println("Element is displayed");

        }


    }


    public static boolean waitUntilElementTobeClickable(WebElement webElement, int timeInSec) {
        try {
            WebDriverWait wait = new WebDriverWait(driver, timeInSec);
            wait.until(ExpectedConditions.elementToBeClickable(webElement));
            return true;
        } catch (Exception e) {
            System.out.println("Element Not Clickable:" + webElement);
            return false;
        }
    }

    public boolean isElementPresent(final WebElement element) {
        waitForBrowserStability(30);
//        waitUntilElementPresent(element);
//        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
        if (element == null)
            return false;
        // Waiting 30 seconds for an element to be present on the page, checking
// for its presence once every 5 seconds.try{
        boolean isPresent = false;
//
//        try {
//            Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
//                    .withTimeout(30, TimeUnit.SECONDS)
//                    .pollingEvery(5, TimeUnit.SECONDS)
//                    .ignoring(NoSuchElementException.class);
//            WebElement foo = null;
//            foo = wait.until(new Function<WebDriver, WebElement>() {
//                public WebElement apply(WebDriver driver) {
//                    return driver.findElement(By.xpath("//div[contains(@class,'ant-notification-notice-message')]"));
//                }
//            });
//            System.out.println(foo.getAttribute("value"));
//
//            System.out.println(foo.isDisplayed());
//            //        });
//            if (foo == null) {
//                isPresent = false;
//            } else
//                isPresent = true;
        try {
            isPresent = element.isDisplayed();
        } catch (StaleElementReferenceException ex) {
            isPresent = element.isDisplayed();
        } catch (NoSuchElementException ex) {
            isPresent = false;
        }
//        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        return isPresent;
    }


    public static List<String> splitString(String inputString, String seperator) {
        List<String> stringList = new ArrayList<>();
        String[] arrOfStr = inputString.split(seperator);
        for (String a : arrOfStr) {
            stringList.add(a);
        }
        return stringList;
    }

    public void refreshPage() throws InterruptedException {
        driver.navigate().refresh();
        Thread.sleep(500);
    }

    Integer retry = 0;

    public void staleElementSendKeys(WebElement webElement, String text) {
        try {

            webElement.clear();
            webElement.click();
            sendKeysCharacters(webElement, text);
            retry = 0;
        } catch (StaleElementReferenceException sere) {
            if (retry <= 10) {
                retry++;
                staleElementSendKeys(webElement, text);
            }
        } catch (InvalidElementStateException invalidStateEx) {
            if (retry <= 10) {
                retry++;
                staleElementSendKeys(webElement, text);
            }
        }
    }

    public String getText(WebElement webElement) {
        String text = "";
        try {
            text = webElement.getText();
            retry = 0;
        } catch (StaleElementReferenceException sere) {
            if (retry <= 5) {
                retry++;
                text = getText(webElement);
            }
        } catch (InvalidElementStateException invalidStateEx) {
            if (retry <= 5) {
                retry++;
                text = getText(webElement);
            }
        }
        return text;
    }

    public WebElement getWebElementByTagInput(WebElement webElement) {
        WebElement element = null;
        try {
            element = webElement.findElement(By.tagName("input"));
            retry = 0;
        } catch (StaleElementReferenceException sere) {
            if (retry <= 5) {
                retry++;
                element = getWebElementByTagInput(webElement);
            }
        } catch (InvalidElementStateException invalidStateEx) {
            if (retry <= 5) {
                retry++;
                element = getWebElementByTagInput(webElement);
            }
        }
        return element;
    }

    public Select selectObject(WebElement webElement) {
        Select element = null;
        try {
            element = new Select(webElement);
            retry = 0;
        } catch (StaleElementReferenceException sere) {
            if (retry <= 5) {
                retry++;
                element = new Select(webElement);
            }
        } catch (InvalidElementStateException invalidStateEx) {
            if (retry <= 5) {
                retry++;
                element = new Select(webElement);
            }
        }
        return element;
    }

    public static void waitForPageLoad() {
        ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");

//                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
        };
        //.executeScript("return jQuery.active") == 0
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(pageLoadCondition);
    }

    public void sendKeysCharactersWebElements(Map<WebElement, String> elements) {

        elements.forEach((k, v) -> {
            sendKeysCharacters(k, v);
        });

    }

    public void sendKeysCharacters(WebElement webElement, String text) {
        for (char c : text.toCharArray()) {
            webElement.sendKeys(Character.toString(c));
        }
    }

    public String getAlertMessage() {
        String Message = "";
        try {
            Alert alert = driver.switchTo().alert();
            Message = driver.switchTo().alert().getText();
            alert.accept();
        } catch (NoAlertPresentException ex) {

        }
        return Message;
    }

    public String getSelectedText(WebElement select) {

        return new Select(select).getFirstSelectedOption().getText();

    }

    public int getSearchCount(WebElement webElement) {
        List<WebElement> searchElements = webElement.findElements(By.tagName("tr"));
        return searchElements.size();
    }

    public void clickElement(WebElement webElement) {

//        waitForBrowserStability("10");

//        waitUntilElementTobeClickable(webElement, 10);
//            return;
        if (webElement.isEnabled()) {
            try {
                try {
                    webElement.click();
                } catch (Exception e) {
//					System.out.println("Clicking Element through :" + strElementName + ":" + getElementProperty(strElementName));
//					clickElementJS(strElementName);
                    ((JavascriptExecutor) driver).executeScript("arguments[0].click();", webElement);
                }
//                waitForBrowserStability("15");
//
            } catch (Exception e) {
                System.out.println("Element Not Clickable:" + e.toString());
            }
        }
    }

    public boolean waitForBrowserStability(int maxTimeInSec) {
        WebDriverWait wait = new WebDriverWait(driver, maxTimeInSec);
        // wait for jQuery to load
        ExpectedCondition<Boolean> jQueryLoad = new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                try {
                    return ((Long) ((JavascriptExecutor) driver)
                            .executeScript("return jQuery.active") == 0);
                } catch (Exception e) {
                    return true;
                }
            }
        };

        // wait for Javascript to load
        ExpectedCondition<Boolean> jsLoad = new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                return ((JavascriptExecutor) driver)
                        .executeScript("return document.readyState")
                        .toString().equals("complete");
            }
        };

        return wait.until(jQueryLoad) && wait.until(jsLoad);
    }


    public boolean waitForBrowserStability2(String maxTimeInSec) {
        boolean bResult = false;
        int maxWait = Integer.parseInt(maxTimeInSec);
        int secsWaited = 0;
        try {
            do {
                Thread.sleep(100);
                secsWaited++;
                if (isBrowserLoaded()) {
                    bResult = true;
                    break;
                }
            } while (secsWaited < (maxWait * 10));
            Thread.sleep(100);
        } catch (Exception e) {
            reportFail("Browser NOT Loaded");

            bResult = false;
        }
//        waitForBrowserStability1("10");
        return bResult;

    }

    public boolean isBrowserLoaded() {
        boolean isBrowserLoaded = false;
        try {
            long timeOut = 5000;
            long end = System.currentTimeMillis() + timeOut;

            while (System.currentTimeMillis() < end) {

                if (String.valueOf(
                        ((JavascriptExecutor) driver)
                                .executeScript("return document.readyState"))
                        .equals("complete")) {
                    isBrowserLoaded = true;
                    break;
                }
            }
        } catch (Exception e) {
            reportFail("Browser NOT Loaded");
        }
        return isBrowserLoaded;
    }

    public static void scrollToElement(WebElement oElement) {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
    }

    public void selectValue(WebElement objElement, String strValue, String strBy) {
//
        if (!waitUntilElementPresent(objElement)) {
            System.out.println("Element Not Found:" + objElement);
            return;
        }

        Select objSelect = new Select(objElement);
//        waitUntilSelectOptionsPopulated(objElement);
        try {

            if (objElement.isEnabled()) {
                if (strBy.equalsIgnoreCase("index")) {
                    objSelect.selectByIndex(Integer.parseInt(strValue));
                } else if (strBy.equalsIgnoreCase("value")) {
                    objSelect.selectByValue(strValue);
                } else if (strBy.equalsIgnoreCase("text")) {
                    objSelect.selectByVisibleText(strValue);
                }

            } else {
                System.out.println("Failed to Selected value in Element : '" + objElement + "' : Element is disabled");
            }
        } catch (Exception e) {
            System.out.println("Failed to Selected value " + strValue + " in Element : '" + objElement + "' : Value not available " + strValue);

        }
    }

    public void setValue(WebElement objElement, String strValue) {
//
//        if (!waitUntilElementPresent(objElement)) {
//            System.out.println("Element Not Found:" + objElement);
//            return;
//        }
        if (objElement.isEnabled()) {
            while (!objElement.getAttribute("value").equals("")) {
                objElement.sendKeys(Keys.BACK_SPACE);
            }
            //objElement.clear();
//            objElement.sendKeys(Keys.SPACE, Keys.BACK_SPACE);
//            objElement.sendKeys(Keys.CONTROL + "a");
//            objElement.sendKeys(Keys.DELETE);
//            (Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
//            objElement.sendKeys(Keys.chord(Keys.CONTROL,"a", Keys.DELETE));
            objElement.sendKeys(strValue);

        } else {
            System.out.println("Failed to Set value in Element : '" + objElement + "' : Element is disabled");
        }
    }

    public static Properties readProperty(String filePath) {
        Properties prop = new Properties();
        try {
            FileReader reader = new FileReader(filePath);
            prop.load(reader);
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("File is not created yet." + e.getMessage());
        }
        return prop;
    }

    public boolean switchToFrame(String frameElement) {
        waitForBrowserStability(30);
        boolean bFlag = false;
        driver.switchTo().defaultContent();
        try {
            driver.switchTo().frame(frameElement);
            waitForPageLoad();
            bFlag = true;
        } catch (Exception e) {
            // TODO: handle exception
            System.out.println("Unable to switch to frame");
        }
        return bFlag;
    }

    public void wait(int timeInSec) {
        try {
            Thread.sleep(timeInSec);
        } catch (Exception e) {

        }
    }
}
