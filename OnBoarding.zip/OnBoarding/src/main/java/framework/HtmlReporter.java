package framework;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.*;
import org.testng.xml.XmlSuite;

import java.io.*;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.*;

public class HtmlReporter implements IReporter {
    public static ExtentReports extent;
    //ExtentHtmlReporter htmlReporter;
    public static ExtentTest test;
    public static ExtentTest testParent;
    public static ExtentTest logger;
    public static ExtentHtmlReporter htmlReporter;
    public static String reportPath, screenshotFolder;
    PrintWriter writer = null;


    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {
        String report = "<html> " +
                "<head> " +
                "<title>ICUE Automation Summary</title> " +
                "<link href=\"../testng.css\" rel=\"stylesheet\" type=\"text/css\" />" +
                "<link href=\"../my-testng.css\" rel=\"stylesheet\" type=\"text/css\" />" +
                "</head> ";
        try {
            writer = new PrintWriter(System.getProperty("user.dir") + "\\Reports\\custom-emailable-report.html", "UTF-8");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }


        for (ISuite suite : suites) {
            Map<String, ISuiteResult> result = suite.getResults();
            suite.getAllMethods().size();
            int totalExecuted = 0, totalPass = 0, totalFail = 0, totalSkip = 0;
            String startDate = null, testCaseSummary = "";

            testCaseSummary = "<table border='1' align='center' style=\"background:#6698ff\">" +
                    "<tr style=\"background:#6698ff\"> <th>Test Name</th> <th>Test Step</th><th>Execution Status</th></tr> ";
            // "<th>Start Time</th> <th>End Time</th></tr> ";
            for (ISuiteResult r : result.values()) {

                ITestContext context = r.getTestContext();
                List<ITestNGMethod> methods = Arrays.asList(context.getAllTestMethods());
//
                totalPass += context.getPassedTests().size();
                totalFail += context.getFailedTests().size();
                totalSkip += context.getSkippedTests().size();
                startDate = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a").format(context.getStartDate());

                for (int i = 0; i < methods.size(); i++) {
                    testCaseSummary += "<tr style=\"background:#bebec2\"> <td>" + r.getTestContext().getName() + "</td>";
                    if (context.getPassedTests().getAllMethods().contains(methods.get(i))) {
                        testCaseSummary += "<td>" + methods.get(i).getMethodName() + "</td> <td style=\"background:#009b00\"> Pass </td>  </tr>";
                        //"<td>" + context.getPassedTests().getResults(). getTime(result.getStartMillis()) + "</td> <td>" + getTime(result.getEndMillis()) + "</td> </tr> ";
                    } else if (context.getFailedTests().getAllMethods().contains(methods.get(i)))
                        testCaseSummary += "<td>" + methods.get(i).getMethodName() + "</td> <td style=\"background:#ff0000\"> Fail </td>  </tr>";
                    else if (context.getSkippedTests().getAllMethods().contains(methods.get(i))) {
                        testCaseSummary += "<td>" + methods.get(i).getMethodName() + "</td> <td style=\"background:#ff8c00\"> Skip </td>  </tr>";

                    }
                }
//
//                testCaseSummary += buildTestNodes(context.getPassedTests(), Status.PASS);
//                testCaseSummary += buildTestNodes(context.getFailedTests(), Status.FAIL);
//                testCaseSummary += buildTestNodes(context.getSkippedTests(), Status.SKIP);
            }
            totalExecuted = totalPass + totalFail + totalSkip;

            testCaseSummary += "</table>";
            try {
                report += "<body> " +
                        "<h2 align='center'>ICUE Automation Summary</h2>" +
                        "<table border='1' align='center' style=\"background:#6698ff\">" +
                        "<tr> <td><b>Suite Name </b></td><td>" + suite.getName() + "</td> </tr> " +
                        "<tr> <td><b>Host Name </b></td><td>" + InetAddress.getLocalHost().getHostName() + "</td> </tr> " +
                        "<tr> <td><b>Operating System </b></td><td>" + System.getProperty("os.name") + "</td> </tr> " +
                        "<tr> <td><b>Executed On </b></td><td>" + startDate + "</td> </tr> " +
                        "<tr> <td><b>Total Executed </b></td><td>" + totalExecuted + "</td> </tr>" +
                        "<tr><td><b>Total Pass </b></td><td>" + totalPass + "</td> </tr> " +
                        "<tr><td><b>Total Fail </b></td><td>" + totalFail + "</td> </tr> " +
                        "<tr><td><b>Total Skip </b></td><td>" + totalSkip + "</td> </tr> </table>";
            } catch (UnknownHostException e) {
                e.printStackTrace();
            }


            report += "<br><br><br>" + testCaseSummary;

        }
        writer.println(report);

        writer.close();
    }

    private String buildTestNodes(IResultMap tests, Status status) {
        String testCase = "";
        if (tests.size() > 0) {
            for (ITestResult result : tests.getAllResults()) {
                if (result.getStatus() == 1) {
                    testCase += "<td>" + result.getMethod().getMethodName() + "</td> <td style=\"background:#009b00\">" + String.valueOf(status).toUpperCase() + "</td>" +
                            "<td>" + getTime(result.getStartMillis()) + "</td> <td>" + getTime(result.getEndMillis()) + "</td> </tr> ";
                }
                if (result.getStatus() == 2) {
                    testCase += "<td>" + result.getMethod().getMethodName() + "</td> <td style=\"background:#ff0000\">" + String.valueOf(status).toUpperCase() + "</td>" +
                            "<td>" + getTime(result.getStartMillis()) + "</td> <td>" + getTime(result.getEndMillis()) + "</td> </tr> ";
                }
                if (result.getStatus() == 2) {
                    testCase += "<td>" + result.getMethod().getMethodName() + "</td> <td style=\"background:#ff8c00\">" + String.valueOf(status).toUpperCase() + "</td>" +
                            "<td>" + getTime(result.getStartMillis()) + "</td> <td>" + getTime(result.getEndMillis()) + "</td> </tr> ";
                }
            }
        }
        return testCase;
    }

    private String getTime(long millis) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(millis);
        return new SimpleDateFormat("dd-MM-yyyy HH:mm:ss a").format(calendar.getTime());
    }

    public static void reportPass(String result) {
        reportAll("Pass", "", result, "", "");
    }

    public static void reportPassFail(Boolean flag, String passResult, String failResult) {
        if (flag) reportAll("Pass_SS", "", passResult, "", "");
        else reportAll("Fail", "", failResult, "", "");

    }

    public static void reportFail(String result) {
        reportAll("Fail", "", result, "", "");
    }

    public static void reportWarning(String strStep, String strExpected, String strActual) {
        reportAll("Warning", strStep, strExpected, strActual, "");
    }

    public static void reportDone(String strStep, String strExpected, String strActual) {
        reportAll("Done", strStep, strExpected, strActual, "");
    }

    public static void reportSkip(String result) {
        reportAll("Skip", "", result, "", "");
    }

    public static void reportInfo(String strStep, String strExpected, String strActual) {
        reportAll("Info", strStep, strExpected, strActual, "");
    }


    public static void reportAll(String strPassFail, String strStep, String strExpected, String
            strActualPass, String strActualFail) {
        test = testParent;
        Base.waitForPageLoad();
        String strScreenShotFile = null;
        String timeStamp = null, strTimeStamp;
        timeStamp = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());
        strTimeStamp = timeStamp.replace(".", "_");
//		 strScreenShotFile=TestDriver.screenshotFolder+"\\Screenshot_"+strTimeStamp + "_" + TestDriver.reporterRow + ".jpg";
        String sFileName = "Screenshot_" + strTimeStamp + ".jpg";
        strScreenShotFile = screenshotFolder + "\\" + sFileName;
        if (!strPassFail.equalsIgnoreCase("Pass")) {
            if (strPassFail.contains("SS"))
                ((JavascriptExecutor) Base.driver).executeScript("window.scrollTo(0,document.body.scrollHeight)");
            //========Capture ScreenShot====================================
//		 strScreenShotFile="ScreenShots"+"\\Screenshot_"+strTimeStamp + "_" + excelconnect.reporterRow + ".jpg";
            // BufferedImage screenFullImage = robot.createScreenCapture(screenRect);
            //ImageIO.write(screenFullImage, "jpg", new File(strScreenShotFile));
            File scrFile = ((TakesScreenshot) Base.driver).getScreenshotAs(OutputType.FILE);
            try {
                FileUtils.copyFile(scrFile, new File(strScreenShotFile));
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            //=================================================================

            try {
//				URL url = new URL("file:ScreenShots/"+"Screenshot_"+strTimeStamp + "_" + TestDriver.reporterRow + ".jpg");

                URL url = new URL("file:" + new File(strScreenShotFile).getAbsolutePath());
//				strScreenShotFile=url.toString();
            } catch (MalformedURLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        System.out.println("***" + strPassFail + "*** - " + strStep + "|" + strExpected + "|" + strActualPass);
        if (strPassFail.equalsIgnoreCase("Pass"))
            test.pass(strStep + "|" + strExpected + "|" + strActualPass + " ");

        else if (strPassFail.equalsIgnoreCase("Pass_SS")) {
            try {
//            test.pass(strStep + "|" + strExpected + "|" + strActualPass + " ");
                test.pass(strStep + "|" + strExpected + "|" + strActualPass + " ", MediaEntityBuilder.createScreenCaptureFromPath("ScreenShots\\" + sFileName).build());
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (strPassFail.equalsIgnoreCase("Fail")) {
            // TestDriver.logger.log(Status.FAIL, strStep + "|" + strExpected + "|" + strActualFail);
            try {
                test.fail(strStep + "|" + strExpected + "|" + strActualFail, MediaEntityBuilder.createScreenCaptureFromPath("ScreenShots\\" + sFileName).build());
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (strPassFail.equalsIgnoreCase("Done")) {
            // TestDriver.logger.log(Status.INFO, strStep + "|" + strExpected + "|" + strActualPass);
            try {
                test.info(strStep + "|" + strExpected + "|" + strActualFail, MediaEntityBuilder.createScreenCaptureFromPath("ScreenShots\\" + sFileName).build());
                //TestDriver.logger.addScreenCaptureFromPath("ScreenShots/" + sFileName);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (strPassFail.equalsIgnoreCase("warning")) {
            // TestDriver.logger.log(Status.WARNING, strStep + "|" + strExpected + "|" + strActualPass);
            try {
                test.warning(strStep + "|" + strExpected + "|" + strActualFail, MediaEntityBuilder.createScreenCaptureFromPath("ScreenShots\\" + sFileName).build());
                //TestDriver.logger.addScreenCaptureFromPath("ScreenShots/" + sFileName);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (strPassFail.equalsIgnoreCase("skip")) {
            // TestDriver.logger.log(Status.WARNING, strStep + "|" + strExpected + "|" + strActualPass);
            try {
                test.skip(strStep + "|" + strExpected + "|" + strActualFail, MediaEntityBuilder.createScreenCaptureFromPath("ScreenShots\\" + sFileName).build());
                //TestDriver.logger.addScreenCaptureFromPath("ScreenShots/" + sFileName);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (strPassFail.equalsIgnoreCase("info")) {
            // TestDriver.logger.log(Status.WARNING, strStep + "|" + strExpected + "|" + strActualPass);
            try {
                test.info(strStep + "|" + strExpected + "|" + strActualFail, MediaEntityBuilder.createScreenCaptureFromPath("ScreenShots\\" + sFileName).build());
                //TestDriver.logger.addScreenCaptureFromPath("ScreenShots/" + sFileName);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }
}
