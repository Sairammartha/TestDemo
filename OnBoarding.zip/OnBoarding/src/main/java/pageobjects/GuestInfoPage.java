package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GuestInfoPage {
    WebDriver driver;

    public GuestInfoPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }


    @FindBy(xpath = "//input[@placeholder='Email Address']")
    WebElement emailAddress;
    @FindBy(xpath = "//input[contains(@id,'salutation')]")
    WebElement salutation;
    //div[@class="ant-select-item-option-content" and text()='Mr.']
    @FindBy(xpath = "//div[@class='ant-select-item-option-content' and text()='Mr.']")
    WebElement selectSalutation;
    @FindBy(xpath = "//input[contains(@id,'firstName')]")
    WebElement firstName;
    @FindBy(xpath = "//input[contains(@id,'lastName')]")
    WebElement lastName;
    @FindBy(xpath = "//input[contains(@id,'address')]")
    WebElement address;
    @FindBy(xpath = "//input[contains(@id,'postal')]")
    WebElement postal;
    @FindBy(xpath = "//input[contains(@id,'country')]")
    WebElement country;
    @FindBy(xpath = "//div[@class='ant-select-item-option-content' and text()='AUSTRALIA']")
    WebElement selectCountry;
    @FindBy(xpath = "//input[contains(@id,'phoneNumber')]")
    WebElement phoneNumber;
    @FindBy(xpath = "//div[contains(@class,'GuestPage_backCheckoutBtn')]//button[2]")
    WebElement enterPayment;
    @FindBy(xpath = "//div[contains(@class,'loaderContainer')]")
    WebElement loader;
    @FindBy(xpath = "//div[@class='ant-modal-body']//button")
    WebElement termsAndConditions;

    public WebElement getTermsAndConditions() {
        return termsAndConditions;
    }
    public WebElement getLoader() {
        return loader;
    }

    public WebElement getEmailAddress() {
        return emailAddress;
    }

    public WebElement getSalutation() {
        return salutation;
    }

    public WebElement getFirstName() {
        return firstName;
    }

    public WebElement getLastName() {
        return lastName;
    }
    public WebElement getAddress() {
        return address;
    }
    public WebElement getPostal() {
        return postal;
    }
    public WebElement getCountry() {
        return country;
    }
    public WebElement getSelectCountry(String country) {
        return driver.findElement(By.xpath(String.format("//div[@class='ant-select-item-option-content' and text()='%s']",country)));
    }
    public WebElement getPhoneNumber() {
        return phoneNumber;
    }
    public WebElement getEnterPayment() {
        return enterPayment;
    }
    public WebElement getSelectSalutation() {
        return selectSalutation;
    }









}
