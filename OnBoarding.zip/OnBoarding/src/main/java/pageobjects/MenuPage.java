package pageobjects;

import framework.Base;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class MenuPage extends Base {
    WebDriver driver;

    public MenuPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[contains(@class,'DashboardFilter_content')]")
    WebElement dashboardFilter;
    @FindBy(xpath = "//div[contains(@class,'DashboardFilter_content')]/..")
    WebElement selectItem;
    @FindBy(xpath = "//div[contains(@class,'DetailItem_bottom')]//button[not(contains(@class,'left'))]")
    WebElement addButton;
    @FindBy(xpath = "//button[contains(text(),' Now')]")
    WebElement orderNowButton;
    @FindBy(xpath = "//div[@class='ant-spin ant-spin-lg ant-spin-spinning']")
    WebElement loader;
    @FindBy(xpath = "//div[contains(@class,'topFilter')]//button[contains(@class,'TopFilters_btn')]")
    WebElement editButton;

    @FindBy(xpath = "//div[@class='itemWrapper']//span[@class='ant-select-arrow']/..")
    WebElement arrowButton;
    //div[@title='Urban Adventures']//div
    @FindBy(xpath = "//div[@class='rc-virtual-list']")
    WebElement selectProvider;

    @FindBy(xpath = "//div[@class='search']/button")
    WebElement searchButton;
    //div[contains(text(),'No results found')]
    @FindBy(xpath = "//div[contains(text(),'No results found')]")
    WebElement noResultFound;


    @FindBy(xpath = "//span[contains(@class,'noDateMsg')]")
    WebElement noDataMsg;
    @FindBy(xpath = "//div[contains(text(),'No results found')]")
    //div[contains(@class,'Results_noRecordsFound')]
    WebElement noRecordsFound;
    @FindBy(xpath = "//span[contains(@class,'noDateMsg')]")
    WebElement noDataMessage;
    @FindBy(xpath = "//div[contains(@class,'SearchAndView_dropdown')]")
    WebElement travelSortBy;
    //div[contains(text(),'Sort by')]
    //div[contains(@class,'antDropDownLink')]
    @FindBy(xpath = "//div[contains(text(),'Sort by')]")
    WebElement hotelSortBy;
    @FindBy(xpath = "//ul[contains(@class,'dropdown')]//li")
    WebElement lowToHigh;
    @FindBy(xpath = "//div[@class='ant-tabs-content-holder']")
    WebElement verifyDetails;
    @FindBy(xpath = "//div[text()='Details']")
    WebElement detailsLink;
    @FindBy(xpath = "//div[text()='Map']")
    WebElement mapLink;
    @FindBy(xpath = "//div[@aria-label='Map']")
    WebElement mapPage;

    @FindBy(xpath = "//div[@role='tab']")
    WebElement tabs;
    @FindBy(xpath = "//div[contains(@class,'ant-notification-notice-message')]")
    WebElement errorMessage;


    @FindBy(xpath = "//div[contains(@class,'Item_content')]//*[contains(@class,'ame')]")
    List<WebElement> bookingItems;

    public List<WebElement> getBookingItems() {
        return bookingItems;
    }

    public WebElement getErrorMessage() {
        return errorMessage;
    }

    public WebElement getTabs() {
        return tabs;
    }
    public WebElement getMapPage() {
        return mapPage;
    }

    public WebElement getMapLink() {
        return mapLink;
    }

    public WebElement getDetailsLink() {
        return detailsLink;
    }

    public WebElement getVerifyDetails() {
        return verifyDetails;
    }


    public WebElement getNoDataMessage() {
        return noDataMessage;
    }

    public WebElement getTravelSortBy() {
        return travelSortBy;
    }

    public WebElement getHotelSortBy() {
        return hotelSortBy;
    }

    public WebElement getLowToHigh() {
        return lowToHigh;
    }


    public WebElement getNoRecordsFound() {
        return noRecordsFound;
    }


    public WebElement getNoDataMsg() {
        return noDataMsg;
    }

    public WebElement getNoResultFound(String provider) {
        return noResultFound;
    }

    public WebElement getSelectProvider(String provider) {
        return selectProvider.findElement(By.xpath(String.format("//div[@title='%s']", provider)));
    }


    public WebElement getSearchButton() {
        return searchButton;
    }

    public WebElement getArrowButton() {
        return arrowButton;
    }

    public WebElement getEditButton() {
        return editButton;
    }

    public WebElement getLoader() {
        return loader;
    }

    public WebElement getDashboardFilter(String dashBoardFilter) {
        //div[text()='Tours & Activities']
        return dashboardFilter.findElement(By.xpath(String.format("//div[contains(@class,'DashboardFilter_content')]//div[text()='%s']", dashBoardFilter)));
    }

    public WebElement getSelectItem(String bookingItem) {
        WebElement webElement = null;
        try {
            webElement = driver.findElement(By.xpath(String.format("//div[contains(@class,'Item')]//*[contains(text(),\"%s\")]", bookingItem)));
        } catch (NoSuchElementException ex) {
        }
        return webElement;
    }

    public WebElement getSelectHotel(String hotelName) {
        WebElement webElement = null;
        try {
            webElement = selectItem.findElement(By.xpath(String.format("//h3[text()='%s']", hotelName)));
        } catch (NoSuchElementException ex) {
        }
        return webElement;
    }

    //h3[text()='%s']
    public WebElement getAddButton() {
        return addButton;
    }

    public WebElement getOrderNow() {
        return orderNowButton;
    }

}

