package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DiningInfoPage {
    WebDriver driver;

    public DiningInfoPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[contains(@class,'DiningListSection')]")
    WebElement diningDetails;
    @FindBy(xpath = "//div[text()='Map']")
    WebElement mapLink;
    @FindBy(xpath = "//div[@aria-label='Map']")
    WebElement mapPage;
    @FindBy(xpath = "//div[text()='Reviews']")
    WebElement review;
    @FindBy(xpath = "//div[contains(@class,'ReviewsSection_main')]")
    WebElement reviewDetails;
    @FindBy(xpath = "//div[contains(@class,'SearchAndView_sort')]//div")
    WebElement sortByFilter;

    @FindBy(xpath = "//li[text()='Ascending']")
    WebElement ascendingOrder;
    @FindBy(xpath = "//div[contains(@class,'DiningSection_dateContainer')]")
    WebElement selectTime;
    public WebElement getSelectTime(String time) {
        return selectTime.findElement(By.xpath(String.format("//span[text()='%s']",time)));
    }
    public WebElement getSortByFilter() {
        return sortByFilter;
    }
    public WebElement getAscendingOrder() {
        return ascendingOrder;
    }
    public WebElement getDiningDetails() {
        return diningDetails;
    }


    public WebElement getMapLink() {
        return mapLink;
    }

    public WebElement getReview() {
        return review;
    }

    public WebElement getReviewDetails() {
        return reviewDetails;
    }


    public WebElement getMapPage() {
        return mapPage;
    }

}
