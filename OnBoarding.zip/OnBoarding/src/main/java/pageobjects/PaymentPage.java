package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PaymentPage {
    WebDriver driver;

    public PaymentPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[@id='credit']")
    WebElement creditCard;
    @FindBy(xpath = "//input[@id='primary_cardName']")
    WebElement cardName;
    @FindBy(xpath = "//input[@autocomplete='cc-number']")
    WebElement cardNumber;
    @FindBy(xpath = "//input[@placeholder='MM/YY']")
    WebElement cardExp;
    @FindBy(xpath = "//input[@placeholder='CVV ']")
    WebElement cvv;
    @FindBy(xpath = "//div[contains(@class,'PaymentsPage_wrapper')]//input[@type='checkbox']")
    WebElement terms;
    @FindBy(xpath = "//button[text()='Check Out']")
    WebElement checkout;

    //button[text()='Check Out']
    @FindBy(xpath = "//div[contains(@class,'loaderContainer')]")
    WebElement loader;

    @FindBy(xpath = "//span[text()='Order Summary']")
    WebElement orderSummary;
    @FindBy(xpath = "//div[@class='ant-notification-notice-message']")
    WebElement errorMessage;
    @FindBy(xpath = "//span[text()='ORDER NUMBER']/..")
    WebElement orderNumber;
    @FindBy(xpath = "//div[contains(@class,'ConfirmationHeader_value')]")
    WebElement orderNumberBC;


    public WebElement getOrderNumber() {
        WebElement webElement = null;
        if (driver.getCurrentUrl().contains("confirmation"))
            webElement = orderNumberBC;
        else if (driver.getCurrentUrl().contains("orderSummary"))
            webElement = orderNumber;
        return webElement;
    }

    public WebElement getOrderSummary() {
        return orderSummary;
    }

    public WebElement getErrorMessage() {
        return errorMessage;
    }

    public WebElement getLoader() {
        return loader;
    }
    //span[text()='Order Summary']

    public WebElement getCardName() {
        return cardName;
    }

    public WebElement getCardNumber() {
        return cardNumber;
    }

    public WebElement getCardExp() {
        return cardExp;
    }

    public WebElement getCvv() {
        return cvv;
    }

    public WebElement getTerms() {
        return terms;
    }

    public WebElement getCheckout() {
        return checkout;
    }


}
