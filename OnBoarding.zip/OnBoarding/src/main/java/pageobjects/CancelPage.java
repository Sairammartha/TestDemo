package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class CancelPage {


    WebDriver driver;

    public CancelPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@name='Enter your order number...']")
    WebElement enterOrderNumber;
    @FindBy(xpath = "//input[@name='Enter your last name...']")
    WebElement lastName;
    @FindBy(xpath = "//button[contains(@class,'orderSearchButton')]")
    WebElement orderSearch;
    @FindBy(xpath = "//div[contains(@class,'errorText')]")
    WebElement errorMessage;
    public WebElement getErrorMessage() {return errorMessage; }

    public WebElement getEnterOrderNumber() {return enterOrderNumber; }

    public WebElement getLastName() {return lastName; }
    public WebElement getOrderSearch() {return orderSearch; }


}
