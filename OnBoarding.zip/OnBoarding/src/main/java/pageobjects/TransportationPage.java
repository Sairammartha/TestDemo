package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class TransportationPage {
    WebDriver driver;

    public TransportationPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//label[contains(@for,'pickUp')]/../..//textarea")
    WebElement pickUp;
    @FindBy(xpath = "//label[contains(@for,'dropOff')]/../..//textarea")
    WebElement dropOff;
    @FindBy(xpath = "//input[@placeholder='Select date']")
    WebElement selectDate;
    @FindBy(xpath = "//label[text()='Passengers']/../..//button[contains(@class,'rightButton')]")
    WebElement addPessengers;
    @FindBy(xpath = "//label[text()='Bags']/../..//button[contains(@class,'rightButton')]")
    WebElement addBags;
    @FindBy(xpath = "//button[@type='submit']")
    WebElement submit;
    @FindBy(xpath = "//div[contains(@class,'ant-notification-notice-message')]")
    WebElement errorMessage;
    @FindBy(xpath = "//div[contains(@class,'TransportListSection_additional')]")
    WebElement details;
    @FindBy(xpath = "//div[text()='Map']")
    WebElement mapLink;
    @FindBy(xpath = "//button[contains(text(),' Now')]")
    WebElement orderNowButton;
    @FindBy(xpath = "//button[text()='View']")
    WebElement viewButton;
    @FindBy(xpath = "//div[contains(@class,'loaderContainer')]")
    WebElement loader;

    @FindBy(xpath = "//div[@aria-label='Map']")
    WebElement mapPage;


    public WebElement getMapPage() {
        return mapPage;
    }
    public WebElement getSelectCity(String city) {
        return driver.findElement(By.xpath(String.format("//div[contains(text(),'%s')]",city)));
    }

    public WebElement getLoader() {
        return loader;
    }

    public WebElement getViewButton() {
        return viewButton;
    }

    public WebElement getPickUp() {
        return pickUp;
    }

    public WebElement getDropOff() {
        return dropOff;
    }

    public WebElement getSelectDate() {
        return selectDate;
    }

    public WebElement getAddPessengers() {
        return addPessengers;
    }

    public WebElement getAddBags() {
        return addBags;
    }

    public WebElement getSubmit() {
        return submit;
    }


    public WebElement getErrorMessage() {
        return errorMessage;
    }

    public WebElement getDetails() {
        return details;
    }

    public WebElement getMapLink() {
        return mapLink;
    }

    public WebElement getOrderNowButton() {
        return orderNowButton;
    }


}
