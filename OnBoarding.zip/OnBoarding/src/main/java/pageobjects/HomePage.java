package pageobjects;

import framework.Base;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.List;

public class HomePage extends Base {
    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//span[@class='ant-select-selection-search']//input[not(@unselectable='on')]")
    WebElement search;
    @FindBy(xpath = "//div[@class='dateWrapper'][1]//input")
    WebElement from;
    @FindBy(xpath = "//div[@class='dateWrapper'][2]//input")
    WebElement untill;
    @FindBy(xpath = "//button[@type='submit']")
    WebElement submitButton;

    @FindBy(xpath = "//div[not(contains(@class,'hidden')) and contains(@class,'ant-picker-dropdown')]//button[@class='ant-picker-year-btn']")
    WebElement yearButton;

    @FindBy(xpath = "//div[not(contains(@class,'hidden')) and contains(@class,'ant-picker-dropdown')]//button[@class='ant-picker-month-btn']")
    WebElement monthButton;
    @FindBy(xpath = "//div[@class='rc-virtual-list-holder-inner']")
    WebElement selectCity;
    @FindBy(xpath = "//div[contains(@class,'HomePage_errorText')]")
    WebElement errorMessage;

    public WebElement getErrorMessage() {
        return errorMessage;
    }


    public WebElement getSearch() {
        return search;
    }

    public WebElement getFrom() {
        return from;
    }

    public WebElement getUntill() {
        return untill;
    }

    public WebElement getSubmitButton() {
        return submitButton;
    }

    public void searchAvailability() {

    }

    public void setDate(String date) {
        clickElement(yearButton);
        clickElement(driver.findElement(By.xpath(String.format("//td[@title='%s']/div", date.split("-")[2]))));
        clickElement(monthButton);
        clickElement(driver.findElement(By.xpath(String.format("//div[not(contains(@class,'hidden')) and contains(@class,'ant-picker-dropdown')]//td[contains(@title,'%s')]/div", "-" + date.split("-")[1]))));
        clickElement(driver.findElement(By.xpath(String.format("//div[not(contains(@class,'hidden')) and contains(@class,'ant-picker-dropdown')]//td[contains(@title,'%s')]/div", date.split("-")[1] + "-" + date.split("-")[0]))));

    }

//    public WebElement getSelectCity(String cityName) {
//        try {
//            wait(1000);
//            return selectCity.findElement(By.xpath(String.format("//div[contains(@title,'%s')]", cityName)));
//        } catch (Exception e) {
//            return selectCity.findElement(By.xpath(String.format("//div[contains(@title,'%s')]", cityName)));
//
//        }
//    }
    public WebElement getSelectCity(String cityName) {
        wait(1000);
        WebElement webElement = null;
        try {
            webElement = selectCity.findElement(By.xpath(String.format("//div[contains(@title,'%s')]", cityName)));
        } catch (NoSuchElementException ex) {
        }
        return webElement;
    }


}
